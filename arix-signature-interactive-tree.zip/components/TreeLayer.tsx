import React, { useRef } from 'react';
import { Mesh, Vector3 } from 'three';
import { useFrame } from '@react-three/fiber';
import { COLORS } from '../constants';

interface TreeLayerProps {
  position: [number, number, number];
  scale: number;
  rotationOffset: number;
}

export const TreeLayer: React.FC<TreeLayerProps> = ({ position, scale, rotationOffset }) => {
  const meshRef = useRef<Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      // Gentle swaying
      meshRef.current.rotation.y = rotationOffset + state.clock.getElapsedTime() * 0.05;
      meshRef.current.rotation.z = Math.sin(state.clock.getElapsedTime() * 0.5 + position[1]) * 0.02;
    }
  });

  return (
    <mesh ref={meshRef} position={new Vector3(...position)} castShadow receiveShadow>
      <coneGeometry args={[1.5 * scale, 2 * scale, 8, 1, true]} />
      {/* Updated to Festive Green */}
      <meshStandardMaterial 
        color={COLORS.festiveGreen}
        roughness={0.3} // Slightly more organic
        metalness={0.1}
        emissive={COLORS.festiveGreen}
        emissiveIntensity={0.15} // Subtle inner glow
        flatShading={false}
      />
    </mesh>
  );
};
import React, { useMemo, useRef } from 'react';
import { InstancedMesh, Object3D } from 'three';
import { useFrame } from '@react-three/fiber';
import { COLORS } from '../constants';

interface OrnamentsProps {
  count: number;
  treeHeight: number;
  treeRadius: number;
}

export const Ornaments: React.FC<OrnamentsProps> = ({ count, treeHeight, treeRadius }) => {
  const meshRef = useRef<InstancedMesh>(null);
  const tempObject = new Object3D();

  // Generate random positions on a cone volume surface
  const particles = useMemo(() => {
    const data = [];
    for (let i = 0; i < count; i++) {
      // Normalized height 0 to 1
      const yNorm = Math.random(); 
      // Radius at this height (cone gets narrower as y increases)
      const currentRadius = treeRadius * (1 - yNorm); 
      
      const angle = Math.random() * Math.PI * 2;
      const r = currentRadius * 0.9; // Slightly inside the leaves
      
      const x = Math.cos(angle) * r;
      const z = Math.sin(angle) * r;
      // Map yNorm to actual height range, lifting it off the ground slightly
      const y = (yNorm * treeHeight * 0.8) - (treeHeight * 0.4) + 1; 

      data.push({ x, y, z, scale: Math.random() * 0.15 + 0.1 });
    }
    return data;
  }, [count, treeHeight, treeRadius]);

  useFrame((state) => {
    if (!meshRef.current) return;

    particles.forEach((particle, i) => {
      const { x, y, z, scale } = particle;
      
      // Rotate ornaments with the tree logic implicitly or independently
      // Here we just place them. For animation, we rotate the group parent usually.
      // Let's make them bob slightly
      const time = state.clock.getElapsedTime();
      
      tempObject.position.set(x, y + Math.sin(time + i) * 0.05, z);
      tempObject.scale.set(scale, scale, scale);
      tempObject.updateMatrix();
      meshRef.current!.setMatrixAt(i, tempObject.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]} castShadow>
      <sphereGeometry args={[1, 32, 32]} />
      {/* Extremely shiny gold material */}
      <meshStandardMaterial 
        color={COLORS.goldMetallic}
        roughness={0.1}
        metalness={1.0}
        envMapIntensity={1.5}
      />
    </instancedMesh>
  );
};
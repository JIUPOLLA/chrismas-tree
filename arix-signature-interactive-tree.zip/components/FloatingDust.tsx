import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Points, Color } from 'three';
import { COLORS } from '../constants';

export const FloatingDust: React.FC = () => {
  const count = 400; // Increased count for more festivity
  const pointsRef = useRef<Points>(null);

  const { positions, colors } = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const tempColor = new Color();

    for (let i = 0; i < count; i++) {
      // Random Positions
      pos[i * 3] = (Math.random() - 0.5) * 15;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 15;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 15;

      // Random Festive Color
      const hex = COLORS.particlePalette[Math.floor(Math.random() * COLORS.particlePalette.length)];
      tempColor.set(hex);
      col[i * 3] = tempColor.r;
      col[i * 3 + 1] = tempColor.g;
      col[i * 3 + 2] = tempColor.b;
    }
    return { positions: pos, colors: col };
  }, [count]);

  useFrame((state) => {
    if (pointsRef.current) {
      // Slow rotation for the whole system
      pointsRef.current.rotation.y = state.clock.getElapsedTime() * 0.05;
      // Gentle wave
      pointsRef.current.rotation.x = Math.sin(state.clock.getElapsedTime() * 0.1) * 0.05;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={count}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.12} // Slightly larger to see the colors
        vertexColors // Enable vertex colors
        transparent
        opacity={0.8}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
};
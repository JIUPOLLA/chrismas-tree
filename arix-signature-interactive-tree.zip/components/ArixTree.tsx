import React from 'react';
import { TreeLayer } from './TreeLayer';
import { Ornaments } from './Ornaments';
import { COLORS } from '../constants';

export const ArixTree: React.FC = () => {
  // Config
  const layers = 5;
  const height = 6;
  const radius = 2.5;

  return (
    <group position={[0, -2, 0]}>
      {/* Tree Layers (Cones) */}
      {Array.from({ length: layers }).map((_, i) => {
        const scale = 1 - (i / (layers + 1));
        const yPos = i * (height / layers) * 0.8;
        return (
          <TreeLayer 
            key={i} 
            position={[0, yPos, 0]} 
            scale={scale} 
            rotationOffset={i * 0.5} 
          />
        );
      })}

      {/* Ornaments */}
      <Ornaments count={50} treeHeight={height} treeRadius={radius} />

      {/* Star Topper */}
      <group position={[0, height * 0.85, 0]}>
         <mesh castShadow>
            <octahedronGeometry args={[0.4, 0]} />
            <meshStandardMaterial 
              color={COLORS.goldHighlight}
              emissive={COLORS.goldHighlight}
              emissiveIntensity={2}
              toneMapped={false} // Allow bloom to blow out
            />
         </mesh>
         {/* Point Light from the Star */}
         <pointLight color={COLORS.goldHighlight} intensity={2} distance={10} decay={2} />
      </group>

      {/* Base/Pot */}
      <mesh position={[0, 0, 0]} receiveShadow>
        <cylinderGeometry args={[0.5, 0.6, 1, 32]} />
        <meshStandardMaterial color="#111" metalness={0.8} roughness={0.2} />
      </mesh>
    </group>
  );
};
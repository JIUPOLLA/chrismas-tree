import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment, ContactShadows } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { ArixTree } from './ArixTree';
import { FloatingDust } from './FloatingDust';
import { COLORS } from '../constants';

export const Scene: React.FC = () => {
  return (
    <Canvas shadows dpr={[1, 2]} gl={{ antialias: false, toneMappingExposure: 1.2 }}>
      <PerspectiveCamera makeDefault position={[0, 2, 9]} fov={45} />
      
      {/* 
        Refined Lighting: Bold, Fresh, Warm 
        High contrast setup with warm key lights and cool/fresh rim lights.
      */}
      
      {/* Ambient: Soft warm filler */}
      <ambientLight intensity={0.6} color="#ffeebb" />
      
      {/* Key Light: Bright, Warm Sunlight from top-right */}
      <spotLight 
        position={[8, 12, 8]} 
        angle={0.4} 
        penumbra={0.3} 
        intensity={20} 
        castShadow 
        shadow-bias={-0.0001}
        color="#fff5e0"
      />

      {/* Fill Light: Rich Gold from the left to warm up shadows */}
      <spotLight 
        position={[-8, 6, 6]} 
        angle={0.6} 
        penumbra={1} 
        intensity={8} 
        color="#ffbf40" 
      />
      
      {/* Rim Light: Sharp, cool-toned fresh light from behind/side to define edges */}
      <spotLight 
        position={[0, 8, -10]} 
        intensity={15} 
        color="#e0ffff" 
        angle={1.2}
      />

      {/* Dramatic Uplight for the gold ornaments */}
      <pointLight position={[3, -3, 3]} intensity={4} color="#ff8822" distance={8} />

      <Suspense fallback={null}>
        {/* Sunset preset gives good warm reflections */}
        <Environment preset="sunset" blur={0.6} background={false} environmentIntensity={0.8} />
        
        <group rotation={[0, 0, 0]}>
          <ArixTree />
          <FloatingDust />
        </group>

        <ContactShadows 
          resolution={1024} 
          scale={20} 
          blur={2} 
          opacity={0.3} 
          far={10} 
          color="#020804" 
        />
      </Suspense>

      <OrbitControls 
        minPolarAngle={Math.PI / 4} 
        maxPolarAngle={Math.PI / 2} 
        enablePan={false}
        enableZoom={true}
        minDistance={5}
        maxDistance={16}
        autoRotate
        autoRotateSpeed={0.8}
      />

      {/* Post Processing: Clean and Glowy */}
      <EffectComposer enableNormalPass={false}>
        <Bloom 
          luminanceThreshold={1.1} 
          mipmapBlur 
          intensity={0.6} 
          radius={0.6}
        />
        <Vignette eskil={false} offset={0.2} darkness={0.8} />
        <Noise opacity={0.015} /> 
      </EffectComposer>
      
      {/* Background: Deep rich green/black, slightly lighter than before for 'freshness' */}
      <color attach="background" args={['#011510']} />
      <fog attach="fog" args={['#011510', 8, 25]} />
    </Canvas>
  );
};
import React, { useState } from 'react';
import { generateLuxuryWish } from '../../services/geminiService';
import { COLORS } from '../../constants';

export const Overlay: React.FC = () => {
  const [wish, setWish] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerateWish = async () => {
    setLoading(true);
    const text = await generateLuxuryWish();
    setWish(text);
    setLoading(false);
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6 md:p-12 z-10">
      
      {/* Header */}
      <header className="flex flex-col items-center md:items-start space-y-2 animate-fade-in-down">
        <h1 className="text-4xl md:text-6xl font-bold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-yellow-500 to-yellow-200 drop-shadow-lg" style={{ fontFamily: 'Cinzel, serif' }}>
          ARIX
        </h1>
        <p className="text-xs md:text-sm tracking-[0.3em] text-yellow-500/80 uppercase">
          Signature Collection
        </p>
      </header>

      {/* Center Message Display */}
      <div className="flex-1 flex items-center justify-center">
        {wish && (
           <div className="bg-black/40 backdrop-blur-md border border-yellow-500/30 p-8 max-w-lg text-center rounded-sm transition-all animate-fade-in-up">
             <p className="text-xl md:text-2xl text-yellow-100 font-serif leading-relaxed italic">
               "{wish}"
             </p>
             <button 
                onClick={() => setWish(null)}
                className="mt-6 pointer-events-auto text-xs text-yellow-500 hover:text-white transition-colors uppercase tracking-widest"
             >
               Close
             </button>
           </div>
        )}
      </div>

      {/* Footer Controls */}
      <footer className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="pointer-events-auto">
          <button
            onClick={handleGenerateWish}
            disabled={loading}
            className="group relative px-8 py-3 bg-transparent overflow-hidden rounded-sm transition-all duration-300"
          >
             <div className="absolute inset-0 w-full h-full border border-yellow-600 group-hover:border-yellow-300 transition-colors duration-300 opacity-60"></div>
             <div className="absolute inset-0 w-0 bg-yellow-600/20 transition-all duration-[250ms] ease-out group-hover:w-full"></div>
             <span className={`relative text-yellow-500 group-hover:text-yellow-100 tracking-widest uppercase text-sm font-semibold transition-colors duration-300 ${loading ? 'animate-pulse' : ''}`}>
               {loading ? 'Crafting...' : 'Reveal Greeting'}
             </span>
          </button>
        </div>

        <div className="text-right hidden md:block">
          <p className="text-yellow-500/40 text-[10px] tracking-widest uppercase">
            Interactive 3D Experience
          </p>
          <p className="text-emerald-800/60 text-[10px] tracking-widest uppercase">
            v1.0.0 • React Three Fiber
          </p>
        </div>
      </footer>
    </div>
  );
};
import React from 'react';
import { Scene } from './components/Scene';
import { Overlay } from './components/UI/Overlay';

const App: React.FC = () => {
  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      {/* 3D Scene Layer */}
      <div className="absolute inset-0 z-0">
        <Scene />
      </div>

      {/* UI Overlay Layer */}
      <Overlay />
      
      {/* Decorative Vignette Overlay (CSS based for extra depth) */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,10,5,0.4)_100%)]"></div>
    </div>
  );
};

export default App;
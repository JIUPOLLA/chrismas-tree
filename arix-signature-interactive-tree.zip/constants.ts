export const COLORS = {
  emeraldDark: '#00241B',
  emeraldLight: '#004d3d',
  festiveGreen: '#0F6B36', // New vivid green
  goldMetallic: '#D4AF37',
  goldHighlight: '#FFD700',
  whiteWarm: '#FFF8E7',
  ambient: '#051410',
  particlePalette: ['#FF0000', '#FFD700', '#FFFFFF', '#00FF00', '#00BFFF'], // Red, Gold, White, Green, Blue
};

export const DEFAULT_TREE_CONFIG = {
  height: 6,
  radius: 2.5,
  layers: 5,
  ornamentCount: 40,
};
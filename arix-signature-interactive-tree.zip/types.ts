export interface TreeConfig {
  height: number;
  radius: number;
  layers: number;
  ornamentCount: number;
}

export interface WishState {
  loading: boolean;
  text: string | null;
  error: string | null;
}

export enum HolidayMode {
  LUXURY = 'luxury',
  PLAYFUL = 'playful',
  MINIMAL = 'minimal'
}
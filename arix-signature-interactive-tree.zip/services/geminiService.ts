import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateLuxuryWish = async (): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: 'Generate a short, very elegant, high-end, one-sentence holiday wish suitable for a luxury brand client. The tone should be sophisticated, warm, and golden. Max 20 words.',
      config: {
        temperature: 0.8,
      }
    });
    
    return response.text.trim();
  } catch (error) {
    console.error("Error generating wish:", error);
    return "May your holidays shine with the brilliance of gold and the peace of emerald.";
  }
};